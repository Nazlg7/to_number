# words2number 0.2.0

* Forked from verajosemanuel/ESmisc and adapted to work English number words
* Added a `NEWS.md` file to track changes to the package.
