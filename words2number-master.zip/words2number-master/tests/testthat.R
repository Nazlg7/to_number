library(testthat)
library(words2number)

test_check("words2number")
